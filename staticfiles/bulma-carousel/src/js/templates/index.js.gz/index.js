export default (id) => {
  return `<div id="${id}" class="slider" tabindex="0">
    <div class="slider-container"></div>
  </div>`;
};